export declare const getCodePoint: (str: string, index: number) => number;
export declare function encodeHTMLTrieRe(regExp: RegExp, str: string): string;
export interface TrieNode {
    value?: string;
    next?: Map<number, TrieNode>;
}
export declare function getTrie(map: Record<string, string>): Map<number, TrieNode>;
//# sourceMappingURL=encode-trie.d.ts.map