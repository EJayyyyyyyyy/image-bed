[http://bluebirdjs.com/docs/changelog.html](http://bluebirdjs.com/docs/changelog.html)
