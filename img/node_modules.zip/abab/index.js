"use strict";

const atob = require("./lib/atob");
const btoa = require("./lib/btoa");

module.exports = {
  atob,
  btoa
};
